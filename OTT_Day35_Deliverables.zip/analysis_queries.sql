
-- Titles by platform
SELECT platform, COUNT(*) AS total_titles
FROM ott_catalog GROUP BY platform;

-- Movies and TV Shows
SELECT type, COUNT(*) AS total_titles
FROM ott_catalog GROUP BY type;

-- Genre counts
SELECT genre, COUNT(*) AS total_titles
FROM ott_catalog GROUP BY genre ORDER BY total_titles DESC;

-- Release year trend
SELECT release_year, COUNT(*) AS total_titles
FROM ott_catalog GROUP BY release_year ORDER BY release_year;
